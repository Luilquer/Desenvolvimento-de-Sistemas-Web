function soma(a, b) {
    var result = parseInt(a) + parseInt(b);
    alert("Soma: " + result);
}